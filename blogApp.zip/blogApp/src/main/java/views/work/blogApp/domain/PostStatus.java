package views.work.blogApp.domain;

public enum PostStatus {
    DRAFT, PUBLISHED
}
