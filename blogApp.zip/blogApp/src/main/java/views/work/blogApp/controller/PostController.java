package views.work.blogApp.controller;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import views.work.blogApp.domain.Post;
import views.work.blogApp.service.PostService;

@Controller
@RequestMapping(path = "/posts")
@RequiredArgsConstructor
public class PostController {

    private final PostService postService;

    //Controller to handle a htpp request coming from a client
    @GetMapping
    public String postPage(Model model) {

        //Post post = new Post();
//        post.setTitle("Hello");
//        post.setDescription("Web blog thymeleaf");
//        post.setBody("Here give the content of your blog smile!");
        model.addAttribute("posts", postService.findAllPosts());
        return "post";
    }

    //this method will provide the form page and attempt a post object
    @GetMapping("/add")
    public String addPostPage(Model model) {
        model.addAttribute("post", new Post());
        return "addPost";
    }
    /*this method will flush the data coming from the form inside the set data structure and redirect
    to the postPage to show the publication
     */
    @PostMapping
    public String addPost(@ModelAttribute("post") Post post) {
        postService.addPost(post);
        return "redirect:/posts";
    }
}
