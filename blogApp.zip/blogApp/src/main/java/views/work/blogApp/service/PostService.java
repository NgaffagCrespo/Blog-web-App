package views.work.blogApp.service;

import views.work.blogApp.domain.Post;

import java.util.Set;

public interface PostService {
    void addPost(Post post);
    Set<Post> findAllPosts();
}
