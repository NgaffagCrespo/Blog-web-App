package views.work.blogApp.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import views.work.blogApp.domain.Post;
import views.work.blogApp.repository.PostRepository;

import java.util.Set;

@Service
@RequiredArgsConstructor
public class PostServiceImpl implements PostService {

    private final PostRepository postRepository;
    @Override
    public void addPost(Post post) {
        postRepository.addPost(post);

    }

    @Override
    public Set<Post> findAllPosts() {
        return postRepository.findAllPosts();
    }
}
